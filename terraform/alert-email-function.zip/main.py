import base64
import os
import json
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail


def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
    message = json.loads(pubsub_message)
    send_email(message['device_id'], message['temperature'])


def send_email(device_id, temperature):

    message = Mail(
        from_email=os.environ.get('FROM_EMAIL'),
        to_emails=os.environ.get('TO_EMAIL'),
        subject=os.environ.get('SUBJECT'),
        html_content=f'<strong>The {device_id} has high Temperature {temperature} !! Please check it... </strong>')
    try:
        sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    except Exception as e:
        print(e)