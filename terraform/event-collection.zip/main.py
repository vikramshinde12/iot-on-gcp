import os
import base64
import json 
from google.cloud import firestore
from google.cloud import pubsub_v1

publisher = pubsub_v1.PublisherClient()
project_id =  os.environ.get('GCP_PROJECT')
topic_id = os.environ.get('ALERT_TOPIC')

def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)
    # print(event)
    # device_id = event['attributes'].get('deviceId')
    # print(device_id)
    message = json.loads(pubsub_message)
    add_into_firestore(message)


def add_into_firestore(message):
    db = firestore.Client()
    doc_ref = db.collection(u'device-data').document()
    doc_ref.set(message)
    
    device_id = message['deviceId']
    if message['temperature'] > int(get_device_threshold(device_id)):
        print('Temperature > threshould... raising alert')
        publish_message(device_id, message['temperature'])



def get_device_threshold(device_id):
    db = firestore.Client()
    doc_ref = db.collection(u'Devices').document(u'{}'.format(device_id))
    doc = doc_ref.get()
    return doc.to_dict().get('threshold', 20)

def publish_message(device_id, temperature):
    topic_path = publisher.topic_path(project_id, topic_id)
    data = {'device_id': device_id, 'temperature': temperature}
    data = json.dumps(data).encode("utf-8")
    # When you publish a message, the client returns a future.
    future = publisher.publish(topic_path, data=data)
    print(future.result())    
